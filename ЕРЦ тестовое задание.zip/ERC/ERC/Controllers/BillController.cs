﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ERC.Models;

namespace ERC.Controllers
{
    public class BillController : Controller
    {
        private readonly ApplicationContext db;
        private Dictionary<string, double> Standarts;
        private Dictionary<string, double> Tariffs;

        public BillController(ApplicationContext context)
        {
            Standarts = new Dictionary<string, double>()
            { {"CW", 4.85 }, {"HW", 4.01}, {"EE", 164}, {"HWTC", 4.01}, {"HWTE", 0.05349} };
            Tariffs = new Dictionary<string, double>()
            { {"CW", 35.78}, {"HW", 158.98 }, {"EE", 4.28}, {"EEDay", 4.9}, {"EENight", 2.31}, {"HWTC", 35.78}, {"HWTE", 998.69}};
            db = context;
        }

        // GET: Bill
        //Отображение квитанций по номеру л/с
        public async Task<IActionResult> Index(int personalAccount)
        {
            if (personalAccount != 0)
            {
                var pa = db.PersonalAccounts.Find(personalAccount);
                if (pa != null)
                {
                    var bills = await db.Bills.Where(p => p.PersonalAccountId == personalAccount).ToListAsync();
                    if (bills.Count == 0) return View(new List<Bill>() { new Bill() { PersonalAccountId = personalAccount, PersonalAccount = pa } });
                    return View(bills);
                }

            }
            
            return View(new List<Bill>() { new Bill() { PersonalAccount = new PersonalAccount()} });
        }

        // GET: Bill/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bill = await db.Bills
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bill == null)
            {
                return NotFound();
            }

            return View(bill);
        }
        //Метод создания или обновления квитанции в БД. Получаем ID текущих и предыдущих показаний, а также номер л/с
        public IActionResult Create(int md0, int md1, int pa)
        {
            var md = new List<MetersData>()
            {
                db.MetersDatas.Find(md0),
                db.MetersDatas.Find(md1)
            };
            var personalAccount = db.PersonalAccounts.Find(pa);
            var bill = CreateBill(md, personalAccount);
            if(!BillExists(bill.Month, bill.Year, pa))
            {
                db.Bills.Add(bill);
                db.SaveChanges();
            }
            else
            {
                var billDB = db.Bills.FirstOrDefault(p => p.Month == bill.Month && p.Year == bill.Year && p.PersonalAccountId == pa);
                billDB.HWTCarrierSum = bill.HWTCarrierSum;
                billDB.HWTEnergySum = bill.HWTEnergySum;
                billDB.EESum = bill.EESum;
                billDB.EEDaySum = bill.EEDaySum;
                billDB.EENightSum = bill.EENightSum;
                billDB.CWSum = bill.CWSum;
                billDB.Sum = bill.Sum;
                db.Bills.Update(billDB);
                db.SaveChanges();
            }
            return RedirectToAction("Index", "MetersData", new { paId = pa});
        }
        //Метод создания объекта квитанции
        public Bill CreateBill(List<MetersData> md, PersonalAccount personalAccount)
        {
            var newBill = new Bill();
            newBill.PersonalAccountId = personalAccount.Id;
            newBill.Month = md[1].Month;
            newBill.Year = md[0].Year;

            newBill.CWSum = Math.Round((md[1].ColdWaterIndicators - md[0].ColdWaterIndicators) * Tariffs["CW"], 2);

            newBill.HWTCarrierSum = Math.Round((md[1].HotWaterIndicators - md[0].HotWaterIndicators) * Tariffs["HWTC"], 2);
            newBill.HWTEnergySum = Math.Round((md[1].HotWaterIndicators - md[0].HotWaterIndicators) * Standarts["HWTE"] * Tariffs["HWTE"], 2);
            
            if(personalAccount.IsEITwoPhases)
            {
                newBill.EEDaySum = Math.Round((md[1].ElectricityDay - md[0].ElectricityDay) * Tariffs["EEDay"], 2);
                newBill.EENightSum = Math.Round((md[1].ElectricityNight - md[0].ElectricityNight) * Tariffs["EENight"], 2);
                newBill.EESum = Math.Round(newBill.EEDaySum + newBill.EENightSum, 2);
            }
            else
            {
                newBill.EESum = Math.Round((md[1].Electricity - md[0].Electricity) * Tariffs["EE"], 2);
            }
            newBill.Sum = Math.Round(newBill.CWSum + newBill.EESum + newBill.EEDaySum + newBill.EENightSum + newBill.HWTCarrierSum + newBill.HWTEnergySum, 2);
            return newBill;
        }

        //Проверка наличия квитанции
        private bool BillExists(int month, int year, int pa)
        {
            return db.Bills.Any(e => e.Month == month && e.Year == year && e.PersonalAccountId == pa);
        }
    }
}
