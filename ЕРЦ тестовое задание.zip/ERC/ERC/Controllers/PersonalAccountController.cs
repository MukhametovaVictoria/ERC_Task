﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ERC.Models;
using Microsoft.AspNetCore.Routing;

namespace ERC.Controllers
{
    public class PersonalAccountController : Controller
    {
        private readonly ApplicationContext db;
        public PersonalAccountController(ApplicationContext context)
        {
            db = context;
        }

        // GET: PersonalAccount
        //Если есть номер л/с, то возвращается объект с данными. Иначе возврат объекта с нулевыми данными
        public IActionResult Index(PersonalAccount pa, int paId)
        {
            if(paId != 0)
            {
                pa = db.PersonalAccounts.Find(paId);
                if (pa == null) pa = new PersonalAccount();
            } 
            else if (pa.City == null || pa.Street == null || pa.House == null) pa = new PersonalAccount();
            else pa = Find(pa);
            return View(pa);
        }


        public IActionResult Create()
        {
            return View();
        }
        //Создание л/с
        [HttpPost]
        public IActionResult Create(PersonalAccount pa, string electricity)
        {
            var user = new User() { Name = pa.User.Name, LastName = pa.User.LastName, PassportNumber = pa.User.PassportNumber };
            switch (electricity) //выбор электросчетчика
            {
                case "One":
                    pa.IsEIOnePhase = true;
                    break;
                case "Two":
                    pa.IsEITwoPhases = true;
                    break;
                case "No":
                    break;
            }
            if (!UserExists(user))
            {
                db.Users.Add(user);
                db.SaveChanges();
            }
            pa.UserId = db.Users.FirstOrDefault(p => p.PassportNumber == user.PassportNumber).Id;

            if (!PersonalAccountExists(pa))
            {
                db.PersonalAccounts.Add(pa);
                db.SaveChanges();
            }
            var paNumber = db.PersonalAccounts.FirstOrDefault(p => p.UserId == pa.UserId
                                                                && p.City == pa.City
                                                                && p.Street == pa.Street
                                                                && p.House == pa.House
                                                                && p.Flat == pa.Flat).Id;
            return RedirectToAction("Index", "PersonalAccount", new { paId = paNumber});
        }
        //Найти л/с по данным из формы
        public PersonalAccount Find(PersonalAccount pa)
        {
            var paFromDB = db.PersonalAccounts.FirstOrDefault(
                p => p.City == pa.City &&
                p.Street == pa.Street &&
                p.House == pa.House &&
                p.Flat == pa.Flat &&
                p.User.PassportNumber == pa.User.PassportNumber &&
                p.User.Name == pa.User.Name &&
                p.User.LastName == pa.User.LastName);

            return paFromDB;
        }

        //Изменить л/с
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personalAccount = await db.PersonalAccounts.FindAsync(id);
            if (personalAccount == null)
            {
                return NotFound();
            }
            return View(personalAccount);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, PersonalAccount personalAccount, string electricity)
        {
            if (id != personalAccount.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    switch(electricity)
                    {
                        case "One":
                            personalAccount.IsEIOnePhase = true;
                            personalAccount.IsEITwoPhases = false;
                            break;
                        case "Two":
                            personalAccount.IsEIOnePhase = false;
                            personalAccount.IsEITwoPhases = true;
                            break;
                        case "No":
                            personalAccount.IsEIOnePhase = false;
                            personalAccount.IsEITwoPhases = false;
                            break;
                    }
                    db.PersonalAccounts.Update(personalAccount);
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PersonalAccountExists(personalAccount))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(personalAccount);
        }
        //Проверка существования л/с
        private bool PersonalAccountExists(PersonalAccount pa)
        {

            return db.PersonalAccounts.Any(
                p => p.City == pa.City &&
                p.Street == pa.Street &&
                p.House == pa.House &&
                p.Flat == pa.Flat &&
                p.UserId == pa.UserId);
        }
        //проверка существования собственника
        private bool UserExists(User user)
        {
            return db.Users.Any(p => p.PassportNumber == user.PassportNumber);
        }
    }
}
