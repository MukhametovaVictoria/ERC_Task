﻿using ERC.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ERC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private ApplicationContext db;
        IWebHostEnvironment _appEnvironment;

        public HomeController(ILogger<HomeController> logger, ApplicationContext context, IWebHostEnvironment appEnvironment)
        {
            _logger = logger;
            db = context;
            _appEnvironment = appEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }
        //Поиск показаний по номеру л/с
        public IActionResult LookMetersDataByPAN()
        {
            return View();
        }
        [HttpPost]
        public IActionResult LookMetersDataByPAN(int number)
        {
            if (number != 0)
            {
                if (db.PersonalAccounts.Any(p => p.Id == number))
                {
                    return RedirectToAction("Index", "MetersData", new { paId = number});
                }
            }
            return RedirectToAction("LookMetersDataByPAN");

        }
        //Ввод лицевого счета для передачи показаний
        public IActionResult EnterPersonalAccountNumber()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> EnterPersonalAccountNumber(int number)
        {
            if (number != 0)
            {
                var pa = await db.PersonalAccounts.FirstOrDefaultAsync(p => p.Id == number);
                

                if (pa != null)
                {
                    if(pa.IsEIOnePhase) //если однофазный счетчик - переход в упрощенную форму
                    {
                        return RedirectToAction("SendMetersDataType1", "MetersData", new { paId = number });
                    }
                    else if(pa.IsEITwoPhases)
                    {
                        return RedirectToAction("SendMetersDataType2", "MetersData", new { paId = number });
                    }
                    else //если нет счетчика, также переход в упрощенную форму
                    {
                        return RedirectToAction("SendMetersDataType1", "MetersData", new { paId = number });
                    }
                }
            }
            return RedirectToAction("EnterPersonalAccountNumber");

        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
