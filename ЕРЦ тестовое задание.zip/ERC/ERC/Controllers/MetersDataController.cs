﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ERC.Models;

namespace ERC.Controllers
{
    public class MetersDataController : Controller
    {
        private readonly ApplicationContext db;
        private Dictionary<string, double> Standarts;

        public MetersDataController(ApplicationContext context)
        {
            db = context;
            Standarts = new Dictionary<string, double>()
            { {"CW", 4.85 }, {"HW", 4.01}, {"EE", 164}, {"HWTC", 4.01}, {"HWTE", 0.05349} };
        }

        // GET: MetersData
        //Если передается номер л/с, то выводятся все показатели по месяцам
        public async Task<IActionResult> Index(int paId)
        {
            if (paId != 0)
            {
                var applicationContext = db.MetersDatas.Where(m => m.PersonalAccountId == paId);
                if(applicationContext.Count() == 0) return View(new List<MetersData>() { new MetersData() { PersonalAccountId = paId} });
                return View(await applicationContext.ToListAsync());
            }
            
            return View(new List<MetersData>() { new MetersData()});
        }
        //Передача показаний через упрощенную форму
        public IActionResult SendMetersDataType1(int paId)
        {
            var metersData = new MetersData() { PersonalAccountId = paId };
            return View(metersData);
        }
        //Передача показаний через расширенную форму
        public IActionResult SendMetersDataType2(int paId)
        {
            var metersData = new MetersData() { PersonalAccountId = paId };
            return View(metersData);
        }

        [HttpPost]
        public async Task<IActionResult> SendMetersDataType1(MetersData data)
        {
            var personal = db.PersonalAccounts.Find(data.PersonalAccountId);
            if (data.ColdWaterIndicators == 0 
                || data.HotWaterIndicators == 0
                || data.Electricity == 0) //если какие-либо показатели нулевые, переход в метод заполнения
            {
                FillNullableFieldsInMetersData(data, personal);
            }
            return await SendToDb(data);
        }

        [HttpPost]
        public async Task<IActionResult> SendMetersDataType2(MetersData data)
        {
            
            var personal = db.PersonalAccounts.Find(data.PersonalAccountId);
            if (data.ColdWaterIndicators == 0
                || data.HotWaterIndicators == 0
                || data.ElectricityDay == 0 || data.ElectricityNight == 0) //если какие-либо показатели нулевые, переход в метод заполнения
            {
                FillNullableFieldsInMetersData(data, personal);
            }
            return await SendToDb(data);
        }
        //Метод отправки показаний в БД и переход к расчету квитанции
        public async Task<IActionResult> SendToDb(MetersData data)
        {
            data.LastDateOfSubmission = DateTime.Now;
            data.Year = DateTime.Now.Year;
            if (!PreviousMetersDataExists(data.Month, data.Year, data.PersonalAccountId))
            {
                var newMD = CreateFirstMetersData(data.Month, data.Year, data.PersonalAccountId);
                db.MetersDatas.Add(newMD);
                db.SaveChanges();
            }
            
            if (!CheckMonth(data.Month, data.Year))
            {
                var md = await db.MetersDatas.FirstOrDefaultAsync(p => p.Month == data.Month && p.Year == data.Year && p.PersonalAccountId == data.PersonalAccountId);
                if (md != null)
                {
                    UpdateMetersData(data, md);
                }
                else
                {
                    if (data.ElectricityDay != 0 || data.ElectricityNight != 0) data.Electricity = data.ElectricityDay + data.ElectricityNight;
                    db.MetersDatas.Add(data);
                    db.SaveChanges();
                }
                
            }

            var md0 = GetPreviousMetersDataId(data.Month, data.Year, data.PersonalAccountId);
            var md1 = db.MetersDatas.FirstOrDefault(p => p.Month == data.Month && p.Year == data.Year && p.PersonalAccountId == data.PersonalAccountId).Id;
            return RedirectToAction("Create", "Bill", new { md0 = md0, md1 = md1, pa = data.PersonalAccountId });
        }
        //Провека существуют ли показания за переданный месяц
        private bool CheckMetersDataExists(MetersData data)
        {
            var dataDB = db.MetersDatas.FirstOrDefault(p => p.Month == data.Month && p.Year == DateTime.Now.Year && p.PersonalAccountId == data.PersonalAccountId);
            if (dataDB != null) return true;
            return false;
        }
        //Заполнение нулевых полей в показаниях
        private void FillNullableFieldsInMetersData(MetersData data, PersonalAccount personal)
        {
            var md = new MetersData();
            if (CheckMetersDataExists(data)) //если за переданный месяц уже существуют показания, то взять данные оттуда
            {
                md = db.MetersDatas.FirstOrDefault(p => p.Month == data.Month && p.Year == DateTime.Now.Year && p.PersonalAccountId == data.PersonalAccountId);
                if (data.ColdWaterIndicators == 0) data.ColdWaterIndicators = md.ColdWaterIndicators;
                if (data.HotWaterIndicators == 0) data.HotWaterIndicators = md.HotWaterIndicators;
                if (data.Electricity == 0) data.Electricity = md.Electricity;
                if (data.ElectricityDay == 0) data.ElectricityDay = md.ElectricityDay;
                if (data.ElectricityNight == 0) data.ElectricityNight = md.ElectricityNight;
            }
            else
            {
                if (PreviousMetersDataExists(data.Month, DateTime.Now.Year, data.PersonalAccountId)) //если есть показания за предыдущий месяц
                {
                    var prevId = GetPreviousMetersDataId(data.Month, DateTime.Now.Year, data.PersonalAccountId);
                    var prevMD = db.MetersDatas.Find(prevId);

                    if (data.ColdWaterIndicators == 0) //добавление нормативов при отсутствии показаний
                        data.ColdWaterIndicators = prevMD.ColdWaterIndicators + Standarts["CW"] * personal.NumberOfResidents;

                    if (data.HotWaterIndicators == 0)
                        data.HotWaterIndicators = prevMD.HotWaterIndicators + Standarts["HW"] * personal.NumberOfResidents;

                    if (!personal.IsEITwoPhases && data.Electricity == 0)
                        data.Electricity = prevMD.Electricity + Standarts["EE"] * personal.NumberOfResidents;

                    if (personal.IsEITwoPhases && data.ElectricityDay == 0)
                        data.ElectricityDay = prevMD.ElectricityDay;
                    if (personal.IsEITwoPhases && data.ElectricityNight == 0)
                        data.ElectricityNight = prevMD.ElectricityNight;
                }
                else //если нет предыдущих показаний (возникает, если показания передаются впервые)
                {
                    if (data.ColdWaterIndicators == 0) //добавление по нормативам
                        data.ColdWaterIndicators = Standarts["CW"] * personal.NumberOfResidents;

                    if (data.HotWaterIndicators == 0)
                        data.HotWaterIndicators = Standarts["HW"] * personal.NumberOfResidents;

                    if (!personal.IsEITwoPhases && data.Electricity == 0)
                        data.Electricity = Standarts["EE"] * personal.NumberOfResidents;
                }
            }
        }
        //Обновление показаний в БД
        private void UpdateMetersData(MetersData data, MetersData md)
        {
            var personal = db.PersonalAccounts.Find(md.PersonalAccountId);
           
            if (personal.IsHWI && data.HotWaterIndicators != 0) md.HotWaterIndicators = data.HotWaterIndicators;
            if (personal.IsCWI && data.ColdWaterIndicators != 0) md.ColdWaterIndicators = data.ColdWaterIndicators;
            if (personal.IsEIOnePhase && data.Electricity != 0) md.Electricity = data.Electricity;
            if (personal.IsEITwoPhases && data.ElectricityDay != 0) md.ElectricityDay = data.ElectricityDay;
            if (personal.IsEITwoPhases && data.ElectricityNight != 0) md.ElectricityNight = data.ElectricityNight;
            if (personal.IsEITwoPhases && (data.ElectricityDay != 0 || data.ElectricityNight != 0)) 
                md.Electricity = data.ElectricityDay + data.ElectricityNight;

            db.MetersDatas.Update(md);
            db.SaveChanges();
        }
        //Создание первичных показаний
        private MetersData CreateFirstMetersData(int month, int year, int pa)
        {
            var prevDates = GetPrevDates(month, year);
            var newMD = new MetersData() { PersonalAccountId = pa, Month = prevDates[0], Year = prevDates[1] };
            return newMD;
        }
        //Получение предыдущих дат
        private int[] GetPrevDates(int month, int year)
        {
            var prevMonth = month - 1;
            if (month == 1)
            {
                prevMonth = 12;
                year = year - 1;
            }
            return new int[] { prevMonth, year };
        }
        //Проверка сущестования предыдущих показаний
        private bool PreviousMetersDataExists(int month, int year, int pa)
        {
            var dates = GetPrevDates(month, year);
            var prev = db.MetersDatas.FirstOrDefault(p => p.Month == dates[0] && p.Year == dates[1] && p.PersonalAccountId == pa);
            if (prev == null) return false;
            return true;
        }
        //Получение ID предыдущих показаний
        private int GetPreviousMetersDataId(int month, int year, int pa)
        {
            var dates = GetPrevDates(month, year);
            return db.MetersDatas.FirstOrDefault(p => p.Month == dates[0] && p.Year == dates[1] && p.PersonalAccountId == pa).Id;
        }
        //Проверка месяца. Если в БД существует связка месяц+год, которые больше, чем у ныне переданных показаний, тогда показания не учитываются
        //Можно отправлять показания только за последний переданный месяц и последующий
        private bool CheckMonth(int month, int year)
        {
            return db.MetersDatas.Any(p => p.Month > month && p.Year >= year);
        }

        private bool MetersDataExists(int id)
        {
            return db.MetersDatas.Any(e => e.Id == id);
        }
    }
}
