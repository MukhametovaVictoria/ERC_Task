﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERC.Models
{
    public class Bill
    {
        public int Id { get; set; }
        public int PersonalAccountId { get; set; }
        public PersonalAccount PersonalAccount { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public double HWTCarrierSum { get; set; }
        public double HWTEnergySum { get; set; }
        public double CWSum { get; set; }
        public double EESum { get; set; }
        public double EEDaySum { get; set; }
        public double EENightSum { get; set; }
        public double Sum { get; set; }
    }
}
