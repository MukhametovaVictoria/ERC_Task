﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ERC.Models
{
    public class MetersData
    {
        public int Id { get; set; }
        public int PersonalAccountId { get; set; }
        public PersonalAccount PersonalAccount { get; set; }
        [Required]
        [Range(1, 12, ErrorMessage = "Недопустимый месяц")]
        public int Month { get; set; }
        public int Year { get; set; }
        public DateTime LastDateOfSubmission { get; set; }
        [Required]
        [RegularExpression(@"[0-9]{1,7}([,]{1}[0-9]{1,3}){1}?", ErrorMessage = "Введите числовые показатели через запятую при наличии дроби")]
        public double ColdWaterIndicators { get; set; }
        [Required]
        [RegularExpression(@"[0-9]{1,7}([,]{1}[0-9]{1,3}){1}?", ErrorMessage = "Введите числовые показатели через запятую при наличии дроби")]
        public double HotWaterIndicators { get; set; }
        [Required]
        [RegularExpression(@"[0-9]{1,7}([,]{1}[0-9]{1,3}){1}?", ErrorMessage = "Введите числовые показатели через запятую при наличии дроби")]
        public double Electricity { get; set; }
        [Required]
        [RegularExpression(@"[0-9]{1,7}([,]{1}[0-9]{1,3}){1}?", ErrorMessage = "Введите числовые показатели через запятую при наличии дроби")]
        public double ElectricityDay { get; set; }
        [Required]
        [RegularExpression(@"[0-9]{1,7}([,]{1}[0-9]{1,3}){1}?", ErrorMessage = "Введите числовые показатели через запятую при наличии дроби")]
        public double ElectricityNight { get; set; }
    }
}
