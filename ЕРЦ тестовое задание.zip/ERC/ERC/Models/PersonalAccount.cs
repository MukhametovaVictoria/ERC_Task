﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ERC.Models
{
    public class PersonalAccount
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
        [Required]
        public int NumberOfResidents { get; set; }
        public bool IsHWI { get; set; }
        public bool IsCWI { get; set; }
        public bool IsEIOnePhase { get; set; }
        public bool IsEITwoPhases { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string Street { get; set; }
        [Required]
        public string House { get; set; }
        public int Flat { get; set; }
    }
}
